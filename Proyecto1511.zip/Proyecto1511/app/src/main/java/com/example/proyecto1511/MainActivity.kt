package com.example.proyecto1511

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    lateinit var textUsuariobox: EditText
    lateinit var textpassbox: EditText
    lateinit var buttonOk: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textUsuariobox = findViewById(R.id.textbox)
        textpassbox = findViewById(R.id.passbox)
        buttonOk = findViewById(R.id.buttonpass)

        buttonOk.setOnClickListener {
            printInfoUserLogin()
        }
    }
    fun printInfoUserLogin(){
        Log.e("Login", "El usuario es :: ${textUsuariobox.text} y su password es :: ${textpassbox.text}" )
    }
}
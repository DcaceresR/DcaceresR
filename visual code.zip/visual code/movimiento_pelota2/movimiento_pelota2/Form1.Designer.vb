﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.JuegoNuevoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ESCSalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Pict2 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.Pict2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.movimiento_pelota2.My.Resources.Resources.FIG_4
        Me.PictureBox1.Location = New System.Drawing.Point(282, 240)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(32, 32)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.JuegoNuevoToolStripMenuItem, Me.ESCSalirToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'JuegoNuevoToolStripMenuItem
        '
        Me.JuegoNuevoToolStripMenuItem.Name = "JuegoNuevoToolStripMenuItem"
        Me.JuegoNuevoToolStripMenuItem.Size = New System.Drawing.Size(88, 20)
        Me.JuegoNuevoToolStripMenuItem.Text = "Juego Nuevo"
        '
        'ESCSalirToolStripMenuItem
        '
        Me.ESCSalirToolStripMenuItem.Name = "ESCSalirToolStripMenuItem"
        Me.ESCSalirToolStripMenuItem.Size = New System.Drawing.Size(72, 20)
        Me.ESCSalirToolStripMenuItem.Text = "ESC= Salir"
        '
        'Timer1
        '
        Me.Timer1.Interval = 500
        '
        'Pict2
        '
        Me.Pict2.BackColor = System.Drawing.Color.Red
        Me.Pict2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict2.Location = New System.Drawing.Point(554, 85)
        Me.Pict2.Name = "Pict2"
        Me.Pict2.Size = New System.Drawing.Size(99, 188)
        Me.Pict2.TabIndex = 2
        Me.Pict2.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Pict2)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.Pict2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents JuegoNuevoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ESCSalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Pict2 As PictureBox
End Class

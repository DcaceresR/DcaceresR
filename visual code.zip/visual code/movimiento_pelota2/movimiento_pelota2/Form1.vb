﻿Public Class Form1
    Dim posx, posy, direccion As Integer
    Dim aleat As New Random
    Dim l1, l2, l3, l4 As Integer

    Private Sub Verificar_pared()
        If PictureBox1.Left > l1 And PictureBox1.Left < l2 Then
            If PictureBox1.Top > l3 And PictureBox1.Top < l4 Then
                Timer1.Enabled = False
                Pict2.BackColor = Color.Blue
            End If
        End If
    End Sub

    Private Sub Verificar_limites()
        If PictureBox1.Left + 80 > Me.Width Then
            Timer1.Enabled = False
        End If
        If PictureBox1.Left - 30 < 0 Then
            Timer1.Enabled = False
        End If
        If PictureBox1.Top - 35 < 0 Then
            Timer1.Enabled = False
        End If
        If PictureBox1.Top + 100 > Me.Height Then
            Timer1.Enabled = False
        End If
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        l1 = Pict2.Left
        l2 = l1 + Pict2.Width
        l3 = Pict2.Top
        l4 = l3 + Pict2.Width
        'l1 = 240
        'l2 = 370
        'l3 = 170
        'l4 = 470

        Timer1.Enabled = True
        direccion = aleat.Next(1, 5)
        Select Case direccion
            Case 1
                posx = -50
                posy = 0
            Case 2
                posx = 50
                posy = 0
            Case 3
                posx = 0
                posy = -50
            Case 4
                posx = 0
                posy = 50
        End Select
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        PictureBox1.Left = PictureBox1.Left + posx
        PictureBox1.Top = PictureBox1.Top + posy
        Verificar_limites()
        Verificar_pared()
    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        'MsgBox(e.KeyCode)
        Select Case e.KeyCode
            Case 37 'izq
                posx = -50
                posy = 0
            Case 38 'arriba
                posx = 0
                posy = -50
            Case 39 'derecha
                posx = 50
                posy = 0
            Case 40 'abajo
                posx = 0
                posy = 50
            Case 27 'esc
                End
        End Select
    End Sub
End Class

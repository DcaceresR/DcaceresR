﻿Public Class Form1
    Dim parque(20), vector(20) As String

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        parque(1) = ("OLHUACA")
        parque(2) = ("NAHUELBUTA")
        parque(3) = ("HUERQUEHUE")
        parque(4) = ("VILLARICA")
        parque(5) = ("CONGUILLIO")
        parque(6) = ("NONGUEN")
        parque(7) = ("LAGUNA DEL LAJA")
        parque(8) = ("MALLECO")
        parque(9) = ("CHINA MUERTA")
        parque(10) = ("ALTO BIOBIO")
        parque(11) = ("MALALCAHUELLO")
        parque(12) = ("LAS VICUÑAS")
        parque(13) = ("RALCO")
        parque(14) = ("ISLA MOCHA")
        parque(15) = ("ALTOS DE PEMEHUE")

    End Sub
    Private Sub EscFinToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EscFinToolStripMenuItem.Click
        End
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        For i = 1 To 15
            If ListBox1.SelectedItem = i Then
                TextBox1.Text = parque(i)
            End If
        Next
    End Sub
End Class

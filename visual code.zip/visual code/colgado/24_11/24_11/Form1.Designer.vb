﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.JuegonuevoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EscFinToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 15
        Me.ListBox1.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"})
        Me.ListBox1.Location = New System.Drawing.Point(217, 12)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(68, 229)
        Me.ListBox1.TabIndex = 0
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.JuegonuevoToolStripMenuItem, Me.EscFinToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(857, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'JuegonuevoToolStripMenuItem
        '
        Me.JuegonuevoToolStripMenuItem.Name = "JuegonuevoToolStripMenuItem"
        Me.JuegonuevoToolStripMenuItem.Size = New System.Drawing.Size(85, 20)
        Me.JuegonuevoToolStripMenuItem.Text = "juego nuevo"
        '
        'EscFinToolStripMenuItem
        '
        Me.EscFinToolStripMenuItem.Name = "EscFinToolStripMenuItem"
        Me.EscFinToolStripMenuItem.Size = New System.Drawing.Size(64, 20)
        Me.EscFinToolStripMenuItem.Text = "esc = fin"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(59, 86)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(152, 23)
        Me.TextBox1.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(85, 68)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 15)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Parque Nacional"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(291, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 21)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "contador="
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(360, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(19, 21)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(309, 68)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 34)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "A"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(346, 68)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(30, 34)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "B"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(382, 68)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 34)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "C"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(419, 68)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(33, 34)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "D"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(456, 68)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(28, 34)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "E"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(493, 68)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(28, 34)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "F"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(530, 68)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(32, 34)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "G"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label11.Location = New System.Drawing.Point(567, 68)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(33, 34)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "H"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(604, 68)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(22, 34)
        Me.Label12.TabIndex = 6
        Me.Label12.Text = "I"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(632, 68)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(25, 34)
        Me.Label13.TabIndex = 6
        Me.Label13.Text = "J"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label14.Location = New System.Drawing.Point(663, 68)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(30, 34)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "K"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label15.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label15.Location = New System.Drawing.Point(699, 68)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(27, 34)
        Me.Label15.TabIndex = 6
        Me.Label15.Text = "L"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label16.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label16.Location = New System.Drawing.Point(732, 68)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(38, 34)
        Me.Label16.TabIndex = 6
        Me.Label16.Text = "M"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label17.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label17.Location = New System.Drawing.Point(776, 68)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(34, 34)
        Me.Label17.TabIndex = 6
        Me.Label17.Text = "N"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label18.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label18.Location = New System.Drawing.Point(299, 118)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(34, 34)
        Me.Label18.TabIndex = 6
        Me.Label18.Text = "Ñ"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label19.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label19.Location = New System.Drawing.Point(339, 118)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(34, 34)
        Me.Label19.TabIndex = 6
        Me.Label19.Text = "O"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label20.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label20.Location = New System.Drawing.Point(379, 118)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(29, 34)
        Me.Label20.TabIndex = 6
        Me.Label20.Text = "P"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label21.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label21.Location = New System.Drawing.Point(414, 118)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(34, 34)
        Me.Label21.TabIndex = 6
        Me.Label21.Text = "Q"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label22.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label22.Location = New System.Drawing.Point(454, 118)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(30, 34)
        Me.Label22.TabIndex = 6
        Me.Label22.Text = "R"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label23.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label23.Location = New System.Drawing.Point(490, 118)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(29, 34)
        Me.Label23.TabIndex = 6
        Me.Label23.Text = "S"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label24.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label24.Location = New System.Drawing.Point(525, 118)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(29, 34)
        Me.Label24.TabIndex = 6
        Me.Label24.Text = "T"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label25.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label25.Location = New System.Drawing.Point(560, 118)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(32, 34)
        Me.Label25.TabIndex = 6
        Me.Label25.Text = "U"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label26.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label26.Location = New System.Drawing.Point(598, 118)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(31, 34)
        Me.Label26.TabIndex = 6
        Me.Label26.Text = "V"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label27.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label27.Location = New System.Drawing.Point(635, 118)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(38, 34)
        Me.Label27.TabIndex = 6
        Me.Label27.Text = "W"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label28.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label28.Location = New System.Drawing.Point(679, 118)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(30, 34)
        Me.Label28.TabIndex = 6
        Me.Label28.Text = "X"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label29.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label29.Location = New System.Drawing.Point(715, 118)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(29, 34)
        Me.Label29.TabIndex = 6
        Me.Label29.Text = "Y"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label30.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label30.Location = New System.Drawing.Point(750, 118)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(30, 34)
        Me.Label30.TabIndex = 6
        Me.Label30.Text = "Z"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label31.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label31.Location = New System.Drawing.Point(85, 284)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(24, 32)
        Me.Label31.TabIndex = 7
        Me.Label31.Text = "_"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label32.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label32.Location = New System.Drawing.Point(114, 284)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(24, 32)
        Me.Label32.TabIndex = 7
        Me.Label32.Text = "_"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label33.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label33.Location = New System.Drawing.Point(143, 284)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(24, 32)
        Me.Label33.TabIndex = 7
        Me.Label33.Text = "_"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label34.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label34.Location = New System.Drawing.Point(172, 284)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(24, 32)
        Me.Label34.TabIndex = 7
        Me.Label34.Text = "_"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label35.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label35.Location = New System.Drawing.Point(201, 284)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(24, 32)
        Me.Label35.TabIndex = 7
        Me.Label35.Text = "_"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label36.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label36.Location = New System.Drawing.Point(230, 284)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(24, 32)
        Me.Label36.TabIndex = 7
        Me.Label36.Text = "_"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label37.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label37.Location = New System.Drawing.Point(260, 284)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(24, 32)
        Me.Label37.TabIndex = 7
        Me.Label37.Text = "_"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label38.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label38.Location = New System.Drawing.Point(290, 284)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(24, 32)
        Me.Label38.TabIndex = 7
        Me.Label38.Text = "_"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label39.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label39.Location = New System.Drawing.Point(320, 284)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(24, 32)
        Me.Label39.TabIndex = 7
        Me.Label39.Text = "_"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label40.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label40.Location = New System.Drawing.Point(350, 284)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(24, 32)
        Me.Label40.TabIndex = 7
        Me.Label40.Text = "_"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label41.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label41.Location = New System.Drawing.Point(379, 284)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(24, 32)
        Me.Label41.TabIndex = 7
        Me.Label41.Text = "_"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label42.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label42.Location = New System.Drawing.Point(409, 284)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(24, 32)
        Me.Label42.TabIndex = 7
        Me.Label42.Text = "_"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label43.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label43.Location = New System.Drawing.Point(439, 284)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(24, 32)
        Me.Label43.TabIndex = 7
        Me.Label43.Text = "_"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label44.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label44.Location = New System.Drawing.Point(469, 284)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(24, 32)
        Me.Label44.TabIndex = 7
        Me.Label44.Text = "_"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label45.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label45.Location = New System.Drawing.Point(499, 284)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(24, 32)
        Me.Label45.TabIndex = 7
        Me.Label45.Text = "_"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label46.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label46.Location = New System.Drawing.Point(529, 284)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(24, 32)
        Me.Label46.TabIndex = 7
        Me.Label46.Text = "_"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(857, 450)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.Label45)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.Label43)
        Me.Controls.Add(Me.Label42)
        Me.Controls.Add(Me.Label41)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Diego Cáceres"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents JuegonuevoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EscFinToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label46 As Label
End Class

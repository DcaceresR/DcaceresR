﻿Module Module1
    Public var1 As Integer
End Module

﻿Public Class Form1
    Dim respuesta As Integer
    Dim ruta As String
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ruta = "..\..\fotos_vb\"
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'MsgBox("mensaje")
        'MessageBox.Show("texto..", "titulo..", btn_accion, icono_aviso)
        respuesta = MessageBox.Show("texto..", "titulo..", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning)
        MsgBox("respuesta=" & respuesta)
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'Form2.Show()
        var1 = var1 + 1
        Form2.ShowDialog()
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged

    End Sub

    Private Sub RadioButton1_Click(sender As Object, e As EventArgs) Handles RadioButton1.Click
        PictureBox1.Image = Image.FromFile(ruta & "FIG_1.ico")
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        PictureBox1.Image = Image.FromFile(ruta & "FIG_2.ico")
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        PictureBox2.Image = Image.FromFile(ruta & "FIG_3.ico")
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        PictureBox2.Image = Image.FromFile(ruta & "FIG_4.ico")
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        PictureBox3.Image = Image.FromFile(ruta & "FIG_5.ico")
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        PictureBox4.Image = Image.FromFile(ruta & "FIG_6.ico")
    End Sub
End Class
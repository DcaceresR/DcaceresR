﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Pict1 = New System.Windows.Forms.PictureBox()
        Me.Pict2 = New System.Windows.Forms.PictureBox()
        Me.Pict3 = New System.Windows.Forms.PictureBox()
        Me.Pict4 = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.JuegoNuevoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EscSalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pict5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.Pict1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pict2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pict3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pict4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.Pict5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pict1
        '
        Me.Pict1.BackColor = System.Drawing.Color.Red
        Me.Pict1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict1.Location = New System.Drawing.Point(750, 300)
        Me.Pict1.Name = "Pict1"
        Me.Pict1.Size = New System.Drawing.Size(30, 30)
        Me.Pict1.TabIndex = 0
        Me.Pict1.TabStop = False
        '
        'Pict2
        '
        Me.Pict2.BackColor = System.Drawing.Color.Blue
        Me.Pict2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict2.Location = New System.Drawing.Point(720, 300)
        Me.Pict2.Name = "Pict2"
        Me.Pict2.Size = New System.Drawing.Size(30, 30)
        Me.Pict2.TabIndex = 1
        Me.Pict2.TabStop = False
        '
        'Pict3
        '
        Me.Pict3.BackColor = System.Drawing.Color.Yellow
        Me.Pict3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict3.Location = New System.Drawing.Point(690, 300)
        Me.Pict3.Name = "Pict3"
        Me.Pict3.Size = New System.Drawing.Size(30, 30)
        Me.Pict3.TabIndex = 2
        Me.Pict3.TabStop = False
        '
        'Pict4
        '
        Me.Pict4.BackColor = System.Drawing.Color.Lime
        Me.Pict4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict4.Location = New System.Drawing.Point(660, 300)
        Me.Pict4.Name = "Pict4"
        Me.Pict4.Size = New System.Drawing.Size(30, 30)
        Me.Pict4.TabIndex = 3
        Me.Pict4.TabStop = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 300
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Location = New System.Drawing.Point(170, 130)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(50, 300)
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox2.Location = New System.Drawing.Point(500, 500)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(300, 50)
        Me.PictureBox2.TabIndex = 4
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.PictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox3.Location = New System.Drawing.Point(1000, 170)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(50, 300)
        Me.PictureBox3.TabIndex = 4
        Me.PictureBox3.TabStop = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.JuegoNuevoToolStripMenuItem, Me.EscSalirToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1288, 24)
        Me.MenuStrip1.TabIndex = 5
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'JuegoNuevoToolStripMenuItem
        '
        Me.JuegoNuevoToolStripMenuItem.Name = "JuegoNuevoToolStripMenuItem"
        Me.JuegoNuevoToolStripMenuItem.Size = New System.Drawing.Size(88, 20)
        Me.JuegoNuevoToolStripMenuItem.Text = "Juego Nuevo"
        '
        'EscSalirToolStripMenuItem
        '
        Me.EscSalirToolStripMenuItem.Name = "EscSalirToolStripMenuItem"
        Me.EscSalirToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.EscSalirToolStripMenuItem.Text = "esc = salir"
        '
        'Pict5
        '
        Me.Pict5.BackColor = System.Drawing.Color.Aqua
        Me.Pict5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict5.Location = New System.Drawing.Point(350, 150)
        Me.Pict5.Name = "Pict5"
        Me.Pict5.Size = New System.Drawing.Size(30, 30)
        Me.Pict5.TabIndex = 6
        Me.Pict5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Aqua
        Me.PictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox4.Location = New System.Drawing.Point(770, 69)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(30, 30)
        Me.PictureBox4.TabIndex = 6
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Aqua
        Me.PictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox5.Location = New System.Drawing.Point(1130, 170)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(30, 30)
        Me.PictureBox5.TabIndex = 6
        Me.PictureBox5.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.Aqua
        Me.PictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox6.Location = New System.Drawing.Point(361, 387)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(30, 30)
        Me.PictureBox6.TabIndex = 6
        Me.PictureBox6.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.Color.Aqua
        Me.PictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox7.Location = New System.Drawing.Point(68, 500)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(30, 30)
        Me.PictureBox7.TabIndex = 6
        Me.PictureBox7.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.Aqua
        Me.PictureBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox8.Location = New System.Drawing.Point(1053, 540)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(30, 30)
        Me.PictureBox8.TabIndex = 6
        Me.PictureBox8.TabStop = False
        '
        'Timer2
        '
        Me.Timer2.Interval = 500
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1288, 620)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.Pict5)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Pict4)
        Me.Controls.Add(Me.Pict3)
        Me.Controls.Add(Me.Pict2)
        Me.Controls.Add(Me.Pict1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.Pict1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pict2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pict3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pict4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.Pict5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Pict1 As PictureBox
    Friend WithEvents Pict2 As PictureBox
    Friend WithEvents Pict3 As PictureBox
    Friend WithEvents Pict4 As PictureBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents JuegoNuevoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EscSalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pict5 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents Timer2 As Timer
End Class

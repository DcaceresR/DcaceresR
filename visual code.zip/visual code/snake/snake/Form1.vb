﻿Public Class Form1
    Dim posx, posy, posx1, posy1, posx2, posy2, posx3, posy3 As Integer
    Dim direccion, l1, l2, l3, l4 As Integer
    Dim cant_paredes As Integer
    Dim aleat As New Random()
    Dim pared(10, 4), cuerpo(30, 3), cuantos_cuerpos, ejex, ejey, ejex1, ejey1 As Integer
    Dim pictu As String



    Private Sub verificar_nuevo_cuerpo()
        If cuerpo(cuantos_cuerpos, 3) = 0 Then
            l1 = cuerpo(cuantos_cuerpos, 1)
            l2 = l1 + 30
            l3 = cuerpo(cuantos_cuerpos, 2)
            l4 = l3 + 30
            'l1 = 350
            'l2 = 380
            'l3 = 150
            'l4 = 180
            If Pict1.Left >= l1 And Pict1.Left <= l2 Then
                If Pict1.Top >= l3 And Pict1.Top <= l4 Then
                    cuerpo(cuantos_cuerpos, 3) = 1
                    cuantos_cuerpos = cuantos_cuerpos + 1
                    MsgBox(cuantos_cuerpos)
                    Timer2.Enabled = True
                End If
            End If
        End If
    End Sub

    Private Sub valores_iniciales()
        Pict1.Left = 750
        Pict1.Top = 300
        Pict2.Left = 720
        Pict2.Top = 300
        Pict3.Left = 690
        Pict3.Top = 300
        Pict4.Left = 660
        Pict4.Top = 300
        'cuerpo(1, 1) = 750
        'cuerpo(1, 2) = 300
        'cuerpo(2, 1) = 720
        'cuerpo(2, 2) = 300
        'cuerpo(3, 1) = 690
        'cuerpo(3, 2) = 300
        'cuerpo(4, 1) = 670
        'cuerpo(4, 2) = 300
        cuerpo(5, 1) = 350
        cuerpo(5, 2) = 150
        cuantos_cuerpos = 4
        cuerpo(1, 3) = 1
        cuerpo(2, 3) = 1
        cuerpo(3, 3) = 1
        cuerpo(4, 3) = 1

        cuerpo(5, 1) = 350
        cuerpo(5, 2) = 150
        cuerpo(6, 1) = 350
        cuerpo(6, 2) = 150
        cuerpo(7, 1) = 350
        cuerpo(7, 2) = 150
        cuerpo(8, 1) = 350
        cuerpo(8, 2) = 150
        cuerpo(9, 1) = 350
        cuerpo(9, 2) = 150




        cant_paredes = 1

        pared(1, 1) = 140
        pared(1, 2) = 190
        pared(1, 3) = 130
        pared(1, 4) = 430

        pared(2, 1) = 500
        pared(2, 2) = 800
        pared(2, 3) = 500
        pared(2, 4) = 550

        pared(3, 1) = 1000
        pared(3, 2) = 1050
        pared(3, 3) = 170
        pared(3, 4) = 470

    End Sub
    Private Sub JuegoNuevoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JuegoNuevoToolStripMenuItem.Click
        valores_iniciales()
        inicio_juego()
    End Sub
    Private Sub verificar_limites_1()
        For i = 1 To cant_paredes
            l1 = pared(i, 1)
            l2 = pared(i, 2)
            l3 = pared(i, 3)
            l4 = pared(i, 4)
            If Pict1.Left >= l1 And Pict1.Left <= l2 Then
                If Pict1.Top >= l3 And Pict1.Top <= l4 Then
                    Timer1.Enabled = False
                    MsgBox("perdió...")
                End If
            End If
        Next
    End Sub
    Private Sub inicio_juego()
        Timer1.Enabled = True
        Timer2.Enabled = True
        direccion = aleat.Next(1, 5)
        direccion = 2
        Select Case direccion
            Case 1
                posx = -30
                posy = 0
            Case 2
                posx = 30
                posy = 0
            Case 3
                posx = 0
                posy = -30
            Case 4
                posx = 0
                posy = 30
            Case 27
                End
        End Select
    End Sub
    Private Sub mover_cabeza()
        ' 1ero guardar coordenadas iniciales
        'posx1 = Pict1.Left
        'posy1 = Pict1.Top
        'posx2 = Pict2.Left
        'posy2 = Pict2.Top
        'posx3 = Pict3.Left
        'posy3 = Pict3.Top

        'For i = 1 To cuantos_cuerpos
        'Me.Controls.Find("pict" & i, True).First().Left = cuerpo(i, 1)
        'Me.Controls.Find("pict" & i, True).First().Top = cuerpo(i, 2)
        'Next

        'cuerpo(1, 1) = Pict1.Left
        'cuerpo(1, 2) = Pict1.Top
        'cuerpo(2, 1) = Pict2.Left
        'cuerpo(2, 2) = Pict2.Top
        'cuerpo(3, 1) = Pict3.Left
        'cuerpo(3, 2) = Pict3.Top
        'cuerpo(4, 1) = Pict4.Left
        'cuerpo(4, 2) = Pict4.Top
        'Select Case cuantos_cuerpos
        ' Case 5
        'cuerpo(5, 1) = Pict5.Left
        'cuerpo(5, 2) = Pict5.Top

        'End Select
        'cuerpo(5, 1) = pict5.left
        'cuerpo(5, 2) = pict5.top

        ' 2do mover cabeza
        'Pict1.Left = Pict1.Left + posx
        'Pict1.Top = Pict1.Top + posy
        'MsgBox(cuerpo(2, 1) & "  " & cuerpo(2, 2))
        ejex = cuerpo(1, 1)
        ejey = cuerpo(1, 2)
        cuerpo(1, 1) = Pict1.Left + posx
        cuerpo(1, 2) = Pict1.Top + posy
        For i = 2 To cuantos_cuerpos
            ejex1 = cuerpo(i, 1)
            ejey1 = cuerpo(i, 2)
            cuerpo(i, 1) = ejex
            cuerpo(i, 2) = ejey
            ejex = ejex1
            ejey = ejey1
        Next
        ' 3ero mover resto del cuerpo
        'Pict1.Left = cuerpo(1, 1)
        'Pict1.Top = cuerpo(1, 2)
        'Pict2.Left = cuerpo(2, 1)
        'Pict2.Top = cuerpo(2, 2)
        'Pict3.Left = cuerpo(3, 1)
        'Pict3.Top = cuerpo(3, 2)
        'Pict4.Left = cuerpo(4, 1)
        'Pict4.Top = cuerpo(4, 2)

        For i = 1 To cuantos_cuerpos
            If cuantos_cuerpos <= 5 Then
                Me.Controls.Find("pict" & i, True).First().Left = cuerpo(i, 1)
                Me.Controls.Find("pict" & i, True).First().Top = cuerpo(i, 2)
            Else
                'MsgBox(cuantos_cuerpos)
                Timer1.Enabled = False
            End If
        Next
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cuantos_cuerpos = 4
        valores_iniciales()
        inicio_juego()
        'cant_paredes = 3
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        mover_cabeza()
        verificar_limites_1()
        verificar_nuevo_cuerpo()
    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        'MsgBox(e.KeyCode)
        Select Case e.KeyCode
            Case 37
                posx = -30
                posy = 0
            Case 38
                posx = 0
                posy = -30
            Case 39
                posx = 30
                posy = 0
            Case 40
                posx = 0
                posy = 30
            Case 27
                End
        End Select
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        cuantos_cuerpos = cuantos_cuerpos + 1
        Timer2.Enabled = False
        If cuantos_cuerpos <= 10 Then
            'Me.Controls.Find("pict" & cuantos_cuerpos, True).First().Visible = True
        Else
            Timer2.Enabled = False
            MsgBox("ganò...completò todos los niveles...")
        End If
    End Sub
End Class

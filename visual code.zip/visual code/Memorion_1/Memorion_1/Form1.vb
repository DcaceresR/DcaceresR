﻿Public Class Form1
    Dim NIVEL, FILAS, COLUMNAS, NUM_PICT, abiertos As Integer
    Dim POSX, POSY, vector(30), n1, n2, paso As Integer
    Dim conta_click, numero_click, numero_foto1, numero_foto2 As Integer
    Dim numero_tag1, numero_tag2, numero_tag3, tope As Integer
    Dim PICT As PictureBox()
    Dim puede_jugar As Boolean
    Dim aleatorio As New Random()
    Dim foto, ruta As String



    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ' deja visible = falso las 2 primeras fotos
        PICT(numero_tag1).Visible = False
        PICT(numero_tag2).Visible = False
        Timer1.Stop()
        puede_jugar = True



    End Sub




    Private Sub desordenar_numeros()
        ' crea y desordena numeros
        ' blanquear vector
        For i = 1 To 30
            vector(i) = 0

        Next


        Select Case NIVEL
            Case 1 ' novato
                For i = 1 To 8
                    If i <= 4 Then
                        vector(i) = i
                    Else
                        vector(i) = i - 4
                    End If
                Next
                tope = 9
            Case 2 ' intermedio
                For i = 1 To 16
                    If i <= 8 Then
                        vector(i) = i
                    Else
                        vector(i) = i - 8
                    End If
                Next
                tope = 17


            Case 3    ' experto
                For i = 1 To 30
                    If i <= 15 Then
                        vector(i) = i
                    Else
                        vector(i) = i - 15
                    End If
                Next
                tope = 31
        End Select

        ' desordenar
        For i = 1 To 100
            n1 = aleatorio.Next(1, tope)
            n2 = aleatorio.Next(1, tope)
            paso = vector(n1)
            vector(n1) = vector(n2)
            vector(n2) = paso
        Next

        '' comprobar fotos
        'For i = 1 To 30
        '    foto = "FIG_" & vector(i) & ".ico"
        '    PICT(i).Image = Image.FromFile(ruta & foto)

        'Next

        'vector(1) = 12
        'vector(2) = 12



    End Sub




    Private Sub FOTO_Click(sender As Object, e As EventArgs)
        ' ADMINISTRA LOS CLICK DE LAS FOTOS
        ' actualizar contador
        Conta_click = conta_click + 1
        Label2.Text = conta_click
        If puede_jugar = True Then

            ' jugar
            numero_click = numero_click + 1
            Select Case numero_click
                Case 1
                    If PICT(sender.tag).Enabled = True Then
                        ' poner foto
                        foto = "FIG_" & vector(sender.tag) & ".ico"
                        PICT(sender.tag).Image = Image.FromFile(ruta & foto)
                        PICT(sender.tag).BackColor = Color.Transparent
                        numero_foto1 = vector(sender.tag)
                        numero_tag1 = sender.tag
                        PICT(sender.tag).Enabled = False
                    Else
                        numero_click = numero_click - 1
                    End If

                Case 2
                    If PICT(sender.tag).Enabled = True Then


                        'poner foto
                        foto = "FIG_" & vector(sender.tag) & ".ico"
                        PICT(sender.tag).Image = Image.FromFile(ruta & foto)
                        PICT(sender.tag).BackColor = Color.Transparent
                        numero_foto2 = vector(sender.tag)
                        numero_tag2 = sender.tag
                        PICT(sender.tag).Enabled = False

                        ' comprobar si foto1=foto2
                        If numero_foto1 = numero_foto2 Then
                            abiertos = abiertos + 1
                            Select Case NIVEL
                                Case 1
                                    If abiertos = 4 Then
                                        Label3.Visible = True
                                    End If
                                Case 2
                                    If abiertos = 8 Then
                                        Label3.Visible = True
                                    End If

                                Case 3


                                    If abiertos = 15 Then
                                        Label3.Visible = True
                                    End If

                            End Select
                            puede_jugar = False
                            Timer1.Start()
                        End If
                    Else
                        numero_click = numero_click - 1

                    End If


                Case 3
                    ' cerrar las 1era 2 fotos

                    ' 1ero inhabilitar 3ra foto
                    numero_tag3 = vector(sender.tag)
                    'PICT(sender.tag).Enabled = False

                    ' 2do habilitar fotos 1 y 2
                    ''PICT(numero_tag1).Enabled = True
                    ''PICT(numero_tag2).Enabled = True

                    ' 3ero cerrar 2 primeras fotos y dejar
                    ' color de fondo
                    PICT(numero_tag1).BackColor = Color.Blue
                    PICT(numero_tag1).Image = Nothing
                    PICT(numero_tag2).BackColor = Color.Blue
                    PICT(numero_tag2).Image = Nothing

                    '4to poner foto del 3er click
                    foto = "FIG_" & vector(sender.tag) & ".ico"
                    PICT(sender.tag).Image = Image.FromFile(ruta & foto)
                    PICT(sender.tag).BackColor = Color.Transparent

                    ' 5to dejar contador de click fotos = 1

                    numero_click = 1
                    numero_foto1 = vector(sender.tag)
                    numero_tag1 = sender.tag



            End Select

        End If

    End Sub

    Private Sub BORRAR_CUADRADOS()
        ' BORRA TODOS LOS CUADRADOS EXISTENTES
        For i = 1 To 5
            For Each xpict In Controls
                If TypeOf xpict Is PictureBox Then
                    Me.Controls.Remove(xpict)
                End If
            Next
        Next

    End Sub


    Private Sub CREAR_CUADRADOS()
        Label3.Visible = False
        numero_click = 0
        puede_jugar = True
        abiertos = 0
        ' BORRAR CUADRADOS EXISTENTES
        BORRAR_CUADRADOS()
        'CREAR  CUADRADOS CUADRADOS SEGUN NIVEL
        Select Case NIVEL
            Case 1   ' NOVATO
                FILAS = 2
                COLUMNAS = 4
            Case 2 ' INTERMEDIO
                FILAS = 4
                COLUMNAS = 4
            Case 3  ' EXPERTO
                FILAS = 5
                COLUMNAS = 6
        End Select

        NUM_PICT = 0
        POSX = 120
        POSY = 80
        PICT = New PictureBox(30) {}

        For I = 1 To FILAS
            For J = 1 To COLUMNAS
                NUM_PICT = NUM_PICT + 1
                PICT(NUM_PICT) = New PictureBox()
                PICT(NUM_PICT).Size = New Size(100, 100)
                PICT(NUM_PICT).Location = New Point(POSX * J, POSY)
                PICT(NUM_PICT).BorderStyle = BorderStyle.FixedSingle
                PICT(NUM_PICT).SizeMode = PictureBoxSizeMode.StretchImage
                PICT(NUM_PICT).Tag = NUM_PICT
                PICT(NUM_PICT).BackColor = Color.Blue

                Me.Controls.Add(PICT(NUM_PICT))
                AddHandler PICT(NUM_PICT).Click, AddressOf FOTO_Click

            Next
            POSY = POSY + 120
        Next
    End Sub




    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ruta = "..\..\fotos_vb\"
    End Sub

    Private Sub NOVATO24ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NOVATO24ToolStripMenuItem.Click
        ' NOVATO
        NIVEL = 1
        ' CREAR CUADRADOS
        ' GENERAR NUMEROS EN VECTOR
        CREAR_CUADRADOS()
        desordenar_numeros()



    End Sub

    Private Sub INTERMEDIO44ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles INTERMEDIO44ToolStripMenuItem.Click
        ' INTERMEDIO
        NIVEL = 2
        ' CREAR CUADRADOS
        ' GENERAR NUMEROS EN VECTOR
        CREAR_CUADRADOS()
        desordenar_numeros()
    End Sub

    Private Sub EXPERTO56ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EXPERTO56ToolStripMenuItem.Click
        ' EXPERTO
        NIVEL = 3
        ' CREAR CUADRADOS
        ' GENERAR NUMEROS EN VECTOR
        CREAR_CUADRADOS()
        desordenar_numeros()
    End Sub
End Class

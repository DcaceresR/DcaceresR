﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.NIVELToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TDSWToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LUNESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NOVATO24ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INTERMEDIO44ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EXPERTO56ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label3 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Location = New System.Drawing.Point(1533, 533)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(150, 94)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Fin"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NIVELToolStripMenuItem, Me.TDSWToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1924, 28)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'NIVELToolStripMenuItem
        '
        Me.NIVELToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NOVATO24ToolStripMenuItem, Me.INTERMEDIO44ToolStripMenuItem, Me.EXPERTO56ToolStripMenuItem})
        Me.NIVELToolStripMenuItem.Name = "NIVELToolStripMenuItem"
        Me.NIVELToolStripMenuItem.Size = New System.Drawing.Size(62, 24)
        Me.NIVELToolStripMenuItem.Text = "NIVEL"
        '
        'TDSWToolStripMenuItem
        '
        Me.TDSWToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LUNESToolStripMenuItem})
        Me.TDSWToolStripMenuItem.Name = "TDSWToolStripMenuItem"
        Me.TDSWToolStripMenuItem.Size = New System.Drawing.Size(64, 24)
        Me.TDSWToolStripMenuItem.Text = "TDSW"
        '
        'LUNESToolStripMenuItem
        '
        Me.LUNESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2})
        Me.LUNESToolStripMenuItem.Name = "LUNESToolStripMenuItem"
        Me.LUNESToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.LUNESToolStripMenuItem.Text = "LUNES"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(224, 26)
        Me.ToolStripMenuItem2.Text = "702"
        '
        'NOVATO24ToolStripMenuItem
        '
        Me.NOVATO24ToolStripMenuItem.Name = "NOVATO24ToolStripMenuItem"
        Me.NOVATO24ToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.NOVATO24ToolStripMenuItem.Text = "NOVATO (2,4)"
        '
        'INTERMEDIO44ToolStripMenuItem
        '
        Me.INTERMEDIO44ToolStripMenuItem.Name = "INTERMEDIO44ToolStripMenuItem"
        Me.INTERMEDIO44ToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.INTERMEDIO44ToolStripMenuItem.Text = "INTERMEDIO(4,4)"
        '
        'EXPERTO56ToolStripMenuItem
        '
        Me.EXPERTO56ToolStripMenuItem.Name = "EXPERTO56ToolStripMenuItem"
        Me.EXPERTO56ToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.EXPERTO56ToolStripMenuItem.Text = "EXPERTO(5,6)"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(931, 80)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(315, 39)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Número de Click ="
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Location = New System.Drawing.Point(1252, 79)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 52)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "0"
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Red
        Me.Label3.Location = New System.Drawing.Point(922, 158)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(638, 191)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Ganó, Felicitaciones....."
        Me.Label3.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(20.0!, 38.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1924, 1055)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents NIVELToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NOVATO24ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents INTERMEDIO44ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EXPERTO56ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TDSWToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LUNESToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label3 As Label
End Class

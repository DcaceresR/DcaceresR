﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Pict1 = New System.Windows.Forms.PictureBox()
        Me.Pict2 = New System.Windows.Forms.PictureBox()
        Me.Pict3 = New System.Windows.Forms.PictureBox()
        Me.Pict4 = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.JuegoNuevoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ESCSAlirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pict5 = New System.Windows.Forms.PictureBox()
        Me.Pict6 = New System.Windows.Forms.PictureBox()
        Me.Pict10 = New System.Windows.Forms.PictureBox()
        Me.Pict9 = New System.Windows.Forms.PictureBox()
        Me.Pict7 = New System.Windows.Forms.PictureBox()
        Me.Pict8 = New System.Windows.Forms.PictureBox()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.Pict1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pict2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pict3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pict4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.Pict5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pict6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pict10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pict9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pict7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pict8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pict1
        '
        Me.Pict1.BackColor = System.Drawing.Color.Red
        Me.Pict1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict1.Location = New System.Drawing.Point(746, 300)
        Me.Pict1.Name = "Pict1"
        Me.Pict1.Size = New System.Drawing.Size(30, 30)
        Me.Pict1.TabIndex = 0
        Me.Pict1.TabStop = False
        '
        'Pict2
        '
        Me.Pict2.BackColor = System.Drawing.Color.Blue
        Me.Pict2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict2.Location = New System.Drawing.Point(720, 300)
        Me.Pict2.Name = "Pict2"
        Me.Pict2.Size = New System.Drawing.Size(30, 30)
        Me.Pict2.TabIndex = 0
        Me.Pict2.TabStop = False
        '
        'Pict3
        '
        Me.Pict3.BackColor = System.Drawing.Color.Yellow
        Me.Pict3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict3.Location = New System.Drawing.Point(690, 300)
        Me.Pict3.Name = "Pict3"
        Me.Pict3.Size = New System.Drawing.Size(30, 30)
        Me.Pict3.TabIndex = 0
        Me.Pict3.TabStop = False
        '
        'Pict4
        '
        Me.Pict4.BackColor = System.Drawing.Color.Green
        Me.Pict4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict4.Location = New System.Drawing.Point(660, 300)
        Me.Pict4.Name = "Pict4"
        Me.Pict4.Size = New System.Drawing.Size(30, 30)
        Me.Pict4.TabIndex = 0
        Me.Pict4.TabStop = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 300
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Location = New System.Drawing.Point(110, 174)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(50, 300)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox2.Location = New System.Drawing.Point(496, 500)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(300, 50)
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.PictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox3.Location = New System.Drawing.Point(994, 174)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(50, 300)
        Me.PictureBox3.TabIndex = 1
        Me.PictureBox3.TabStop = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.JuegoNuevoToolStripMenuItem, Me.ESCSAlirToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1300, 36)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'JuegoNuevoToolStripMenuItem
        '
        Me.JuegoNuevoToolStripMenuItem.Name = "JuegoNuevoToolStripMenuItem"
        Me.JuegoNuevoToolStripMenuItem.Size = New System.Drawing.Size(141, 32)
        Me.JuegoNuevoToolStripMenuItem.Text = "Juego Nuevo"
        '
        'ESCSAlirToolStripMenuItem
        '
        Me.ESCSAlirToolStripMenuItem.Name = "ESCSAlirToolStripMenuItem"
        Me.ESCSAlirToolStripMenuItem.Size = New System.Drawing.Size(124, 32)
        Me.ESCSAlirToolStripMenuItem.Text = "ESC = SAlir"
        '
        'Pict5
        '
        Me.Pict5.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Pict5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict5.Location = New System.Drawing.Point(350, 150)
        Me.Pict5.Name = "Pict5"
        Me.Pict5.Size = New System.Drawing.Size(30, 30)
        Me.Pict5.TabIndex = 0
        Me.Pict5.TabStop = False
        Me.Pict5.Visible = False
        '
        'Pict6
        '
        Me.Pict6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Pict6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict6.Location = New System.Drawing.Point(750, 100)
        Me.Pict6.Name = "Pict6"
        Me.Pict6.Size = New System.Drawing.Size(30, 30)
        Me.Pict6.TabIndex = 0
        Me.Pict6.TabStop = False
        Me.Pict6.Visible = False
        '
        'Pict10
        '
        Me.Pict10.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Pict10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict10.Location = New System.Drawing.Point(1100, 550)
        Me.Pict10.Name = "Pict10"
        Me.Pict10.Size = New System.Drawing.Size(30, 30)
        Me.Pict10.TabIndex = 0
        Me.Pict10.TabStop = False
        Me.Pict10.Visible = False
        '
        'Pict9
        '
        Me.Pict9.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Pict9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict9.Location = New System.Drawing.Point(200, 400)
        Me.Pict9.Name = "Pict9"
        Me.Pict9.Size = New System.Drawing.Size(30, 30)
        Me.Pict9.TabIndex = 0
        Me.Pict9.TabStop = False
        Me.Pict9.Visible = False
        '
        'Pict7
        '
        Me.Pict7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Pict7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict7.Location = New System.Drawing.Point(1100, 150)
        Me.Pict7.Name = "Pict7"
        Me.Pict7.Size = New System.Drawing.Size(30, 30)
        Me.Pict7.TabIndex = 0
        Me.Pict7.TabStop = False
        Me.Pict7.Visible = False
        '
        'Pict8
        '
        Me.Pict8.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Pict8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict8.Location = New System.Drawing.Point(500, 300)
        Me.Pict8.Name = "Pict8"
        Me.Pict8.Size = New System.Drawing.Size(30, 30)
        Me.Pict8.TabIndex = 0
        Me.Pict8.TabStop = False
        Me.Pict8.Visible = False
        '
        'Timer2
        '
        Me.Timer2.Interval = 500
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1300, 703)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Pict8)
        Me.Controls.Add(Me.Pict7)
        Me.Controls.Add(Me.Pict9)
        Me.Controls.Add(Me.Pict10)
        Me.Controls.Add(Me.Pict6)
        Me.Controls.Add(Me.Pict5)
        Me.Controls.Add(Me.Pict4)
        Me.Controls.Add(Me.Pict3)
        Me.Controls.Add(Me.Pict2)
        Me.Controls.Add(Me.Pict1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(5)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.Pict1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pict2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pict3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pict4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.Pict5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pict6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pict10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pict9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pict7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pict8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Pict1 As PictureBox
    Friend WithEvents Pict2 As PictureBox
    Friend WithEvents Pict3 As PictureBox
    Friend WithEvents Pict4 As PictureBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents JuegoNuevoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ESCSAlirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pict5 As PictureBox
    Friend WithEvents Pict6 As PictureBox
    Friend WithEvents Pict10 As PictureBox
    Friend WithEvents Pict9 As PictureBox
    Friend WithEvents Pict7 As PictureBox
    Friend WithEvents Pict8 As PictureBox
    Friend WithEvents Timer2 As Timer
End Class

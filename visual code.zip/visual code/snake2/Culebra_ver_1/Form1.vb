﻿Public Class Form1
    Dim posx, posy, posx1, posy1, posx2, posy2, posx3, posy3 As Integer
    Dim direccion, l1, l2, l3, l4 As Integer
    Dim cant_paredes, cuerpos_activos As Integer
    Dim aleat As New Random()
    Dim pared(10, 4), cuerpo(30, 3), cuantos_cuerpos, ejex, ejey, ejex1, ejey1 As Integer
    Dim pictu As String



    Private Sub Button1_Click(sender As Object, e As EventArgs)
        ' extraer caracteres de una frase y pasarla a un vector
        Dim texto, vector(20) As String
        Dim largo As Integer
        texto = "Coquimbo"
        largo = Len(texto)
        MsgBox("largo del texto = " & largo)

        ' pasar cada caracter de texto al vector
        '  MsgBox(Mid(texto, 4, 2))
        For i = 1 To largo
            vector(i) = Mid(texto, i, 1)
            MsgBox(vector(i))
        Next





    End Sub


    Private Sub verificar_nuevo_cuerpo()
        ' verifica tope con nuevo cuerpo y lo agrega a la cola
        ' se mueve con el resto del cuerpo
        ' limites del nuevo cuerpo
        'MsgBox(cuantos_cuerpos)

        If cuerpo(cuantos_cuerpos, 3) = 0 Then
            ' MsgBox(cuantos_cuerpos)
            l1 = cuerpo(cuantos_cuerpos, 1)
            l2 = l1 + 30
            l3 = cuerpo(cuantos_cuerpos, 2)
            l4 = l3 + 30
            'MsgBox(l1 & "   " & l2 & "   " & l3 & "   " & l4)
            If Pict1.Left >= l1 And Pict1.Left <= l2 Then
                If Pict1.Top >= l3 And Pict1.Top <= l4 Then
                    'topamos.
                    'Timer1.Enabled = False
                    'MsgBox("topó.......")
                    cuerpo(cuantos_cuerpos, 3) = 1
                    cuerpos_activos = cuerpos_activos + 1
                    'cuantos_cuerpos = cuantos_cuerpos + 1
                    ' MsgBox(cuantos_cuerpos)

                    Timer2.Enabled = True
                End If
            End If

        End If
    End Sub



    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        ' visibiliza los cuerpos
        cuantos_cuerpos = cuantos_cuerpos + 1
        Me.Controls.Find("pict" & cuantos_cuerpos, True).First().Visible = True
        Timer2.Enabled = False
        ' MsgBox("..............")
        'If cuantos_cuerpos <= 10 Then

        'Else
        '    Timer2.Enabled = False
        '    MsgBox("Ganó...completó todos los niveles...")

        'End If


    End Sub






    Private Sub valores_iniciales()
        ' posicion inicial de cabeza y cuerpo de culebra
        Pict1.Left = 750
        Pict1.Top = 300
        Pict2.Left = 720
        Pict2.Top = 300
        Pict3.Left = 690
        Pict3.Top = 300
        Pict4.Left = 660
        Pict4.Top = 300
        cuerpo(1, 3) = 1
        cuerpo(2, 3) = 1
        cuerpo(3, 3) = 1
        cuerpo(4, 3) = 1

        cuerpo(5, 1) = 350  ' l1 
        cuerpo(5, 2) = 150  'l2
        cuerpo(6, 1) = 750
        cuerpo(6, 2) = 100
        cuerpo(7, 1) = 1100
        cuerpo(7, 2) = 150
        cuerpo(8, 1) = 500
        cuerpo(8, 2) = 300
        cuerpo(9, 1) = 200
        cuerpo(9, 2) = 400
        cuerpo(10, 1) = 1100
        cuerpo(10, 2) = 550


        cuantos_cuerpos = 4
        cuerpos_activos = 4
        cant_paredes = 1
        ' valores iniciales de pared1
        'l1 = 140
        'l2 = 190
        'l3 = 130
        'l4 = 430

        ' limites de cada pared, en matriz pared(10,4)
        ' pared1
        pared(1, 1) = 140
        pared(1, 2) = 190
        pared(1, 3) = 130
        pared(1, 4) = 430

        ' pared2
        pared(2, 1) = 500
        pared(2, 2) = 800
        pared(2, 3) = 500
        pared(2, 4) = 550

        ' pared3
        pared(3, 1) = 1000
        pared(3, 2) = 1050
        pared(3, 3) = 170
        pared(3, 4) = 470

    End Sub




    Private Sub JuegoNuevoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JuegoNuevoToolStripMenuItem.Click
        ' juego nuevo

        '  dejar todo con posiciones y valores iniciales
        valores_iniciales()
        inicio_juego()


    End Sub


    Private Sub verificar_limites_1()
        ' verificar limites de pared1

        ' limites de cada pared en pared(10,4) y el uso
        ' del ciclo FOR para verificar TODAS las paredes

        For i = 1 To cant_paredes
            l1 = pared(i, 1)
            l2 = pared(i, 2)
            l3 = pared(i, 3)
            l4 = pared(i, 4)

            If Pict1.Left >= l1 And Pict1.Left <= l2 Then
                If Pict1.Top >= l3 And Pict1.Top <= l4 Then
                    'topamos.
                    Timer1.Enabled = False
                    MsgBox("perdió.......")
                End If
            End If
        Next

    End Sub

    Private Sub inicio_juego()
        ' inicio del juego

        ' inicio del timer1
        Timer1.Enabled = True
        Timer2.Enabled = True
        '  determinar la direccion de movimiento
        direccion = aleat.Next(1, 5)
        direccion = 2   ' dejé en 2, derecha, sólo para efectos de control
        Select Case direccion
            Case 1   ' izq
                posx = -30
                posy = 0

            Case 2   ' derecha
                posx = 30
                posy = 0

            Case 3   ' arriba
                posx = 0
                posy = -30

            Case 4    ' abajo
                posx = 0
                posy = 30

        End Select
    End Sub


    Private Sub mover_cabeza()
        ' guardar posiciones


        ' mover cuerpo
        ejex = cuerpo(1, 1)
        ejey = cuerpo(1, 2)
        cuerpo(1, 1) = Pict1.Left + posx
        cuerpo(1, 2) = Pict1.Top + posy

        For i = 2 To cuerpos_activos ' cuantos_cuerpos
            ejex1 = cuerpo(i, 1) ' actual
            ejey1 = cuerpo(i, 2)
            cuerpo(i, 1) = ejex
            cuerpo(i, 2) = ejey
            ejex = ejex1
            ejey = ejey1
        Next

        For i = 1 To cuerpos_activos ' cuantos_cuerpos
            Me.Controls.Find("pict" & i, True).First().Left = cuerpo(i, 1)
            Me.Controls.Find("pict" & i, True).First().Top = cuerpo(i, 2)
            'Me.Controls.Find("pict" & i, True).First.BackColor = Color.White
        Next

    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' inicia valores,determina direcion inicial y juega
        cuantos_cuerpos = 4
        valores_iniciales()
        inicio_juego()

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ' mover cabeza
        mover_cabeza()

        ' verificar limites de pared1
        ' verificar_limites_1()
        verificar_nuevo_cuerpo()


    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        ' teclas de movimiento
        'cambia de direccion según tecla presionada
        'MsgBox(e.KeyCode)
        Select Case e.KeyCode
            Case 37  ' izq
                posx = -30
                posy = 0
            Case 38   ' arriba
                posx = 0
                posy = -30
            Case 39  ' derecha
                posx = 30
                posy = 0
            Case 40 ' abajo
                posx = 0
                posy = 30
            Case 27 ' esc
                End
        End Select

    End Sub
End Class

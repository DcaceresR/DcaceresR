﻿Public Class Form1
    Dim aleat As New Random()
    Dim valorApos, clicku, resultado As Integer
    Dim apuesta As String
    Dim azar As New Random

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        If ListBox1.SelectedItem Then
            clicku = 0
            resultado = 0
            Label2.Text = 0
            Label3.Text = 0
            Label4.Text = 0
            Label5.Text = 0
            Label6.Text = 0
            Label1.Text = ListBox1.SelectedItem
            apuesta = Int(Label1.Text)
            Label12.Text = ("0")
        End If
    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        clicku = 1
        resultado = 0
    End Sub

    Private Sub verificar_par()
        If Label2.Text = Label3.Text Then
            If resultado = 0 Then
                Label12.Text = ("par!")
                Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                resultado = 1
            End If
        End If

        If Label2.Text = Label4.Text Then
            If resultado = 0 Then
                Label12.Text = ("par!")
                Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                resultado = 1
            End If
        End If

        If Label2.Text = Label5.Text Then
            If resultado = 0 Then
                Label12.Text = ("par!")
                Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                resultado = 1
            End If
        End If

        If Label2.Text = Label6.Text Then
            If resultado = 0 Then
                Label12.Text = ("par!")
                Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                resultado = 1
            End If
        End If

        If Label3.Text = Label4.Text Then
            If resultado = 0 Then
                Label12.Text = ("par!")
                Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                resultado = 1
            End If
        End If

        If Label3.Text = Label5.Text Then
            If resultado = 0 Then
                Label12.Text = ("par!")
                Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                resultado = 1
            End If
        End If

        If Label3.Text = Label6.Text Then
            If resultado = 0 Then
                Label12.Text = ("par!")
                Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                resultado = 1
            End If
        End If

        If Label4.Text = Label5.Text Then
            If resultado = 0 Then
                Label12.Text = ("par!")
                Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                resultado = 1
            End If
        End If

        If Label4.Text = Label6.Text Then
            If resultado = 0 Then
                Label12.Text = ("par!")
                Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                resultado = 1
            End If
        End If

        If Label5.Text = Label6.Text Then
            If resultado = 0 Then
                Label12.Text = ("par!")
                Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                resultado = 1
            End If
        End If
    End Sub

    Private Sub verificar_doble_par()

        If Label2.Text = Label3.Text Then
            If Label4.Text = Label5.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label3.Text Then
            If Label5.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label4.Text Then
            If Label5.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label4.Text Then
            If Label3.Text = Label5.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label3.Text Then
            If Label4.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If


        If Label2.Text = Label4.Text Then
            If Label3.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label5.Text Then
            If Label3.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label5.Text Then
            If Label4.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label3.Text = Label4.Text Then
            If Label5.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label3.Text = Label5.Text Then
            If Label4.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label5.Text Then
            If Label3.Text = Label4.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label6.Text Then
            If Label3.Text = Label4.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label6.Text Then
            If Label3.Text = Label5.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label6.Text Then
            If Label4.Text = Label5.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label3.Text = Label6.Text Then
            If Label4.Text = Label5.Text Then
                If resultado = 0 Then
                    Label12.Text = ("doble par!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

    End Sub

    Private Sub verificar_trio()
        If Label2.Text = Label3.Text Then
            If Label3.Text = Label4.Text Then
                If resultado = 0 Then
                    Label12.Text = ("trio!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label3.Text Then
            If Label3.Text = Label5.Text Then
                If resultado = 0 Then
                    Label12.Text = ("trio!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label3.Text Then
            If Label3.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("trio!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label4.Text Then
            If Label4.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("trio!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label5.Text Then
            If Label5.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("trio!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label3.Text = Label5.Text Then
            If Label5.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("trio!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label4.Text = Label5.Text Then
            If Label5.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("trio!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label2.Text = Label4.Text Then
            If Label4.Text = Label5.Text Then
                If resultado = 0 Then
                    Label12.Text = ("trio!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label3.Text = Label4.Text Then
            If Label3.Text = Label5.Text Then
                If resultado = 0 Then
                    Label12.Text = ("trio!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If

        If Label3.Text = Label4.Text Then
            If Label4.Text = Label6.Text Then
                If resultado = 0 Then
                    Label12.Text = ("trio!")
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                    resultado = 1
                End If
            End If
        End If
    End Sub

    Private Sub verificar_trio_par()
        If Label2.Text = Label3.Text Then
            If Label3.Text = Label4.Text Then
                If Label5.Text = Label6.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("trio y par!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If

        If Label2.Text = Label3.Text Then
            If Label3.Text = Label5.Text Then
                If Label4.Text = Label6.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("trio y par!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If

        If Label2.Text = Label3.Text Then
            If Label3.Text = Label6.Text Then
                If Label4.Text = Label5.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("trio y par!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If

        If Label2.Text = Label4.Text Then
            If Label4.Text = Label6.Text Then
                If Label3.Text = Label5.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("trio y par!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If

        If Label2.Text = Label5.Text Then
            If Label5.Text = Label6.Text Then
                If Label3.Text = Label4.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("trio y par!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If

        If Label3.Text = Label5.Text Then
            If Label5.Text = Label6.Text Then
                If Label2.Text = Label3.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("trio y par!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If

        If Label4.Text = Label5.Text Then
            If Label5.Text = Label6.Text Then
                If Label2.Text = Label3.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("trio y par!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If

        If Label2.Text = Label4.Text Then
            If Label4.Text = Label5.Text Then
                If Label3.Text = Label6.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("trio y par!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If

        If Label3.Text = Label4.Text Then
            If Label3.Text = Label5.Text Then
                If Label2.Text = Label6.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("trio y par!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If

        If Label3.Text = Label4.Text Then
            If Label4.Text = Label6.Text Then
                If Label2.Text = Label5.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("trio  y par!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub verificar_cuarteto()

        If Label2.Text = Label3.Text Then
            If Label3.Text = Label4.Text Then
                If Label4.Text = Label5.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("cuarteto!!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If

        If Label2.Text = Label3.Text Then
            If Label3.Text = Label4.Text Then
                If Label4.Text = Label6.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("cuarteto!!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If

        If Label2.Text = Label3.Text Then
            If Label3.Text = Label5.Text Then
                If Label5.Text = Label6.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("cuarteto!!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If

        If Label2.Text = Label4.Text Then
            If Label4.Text = Label5.Text Then
                If Label5.Text = Label6.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("cuarteto!!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If

        If Label3.Text = Label4.Text Then
            If Label4.Text = Label5.Text Then
                If Label5.Text = Label6.Text Then
                    If resultado = 0 Then
                        Label12.Text = ("cuarteto!!")
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                        resultado = 1
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub verificar_quinteto()
        If Label2.Text = Label3.Text Then
            If Label3.Text = Label4.Text Then
                If Label4.Text = Label5.Text Then
                    If Label5.Text = Label6.Text Then
                        If resultado = 0 Then
                            Label12.Text = ("quinteto!!!")
                            Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                            Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                            Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                            Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                            Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                            Label10.Text = Int(Label1.Text) + Int(Label10.Text)
                            resultado = 1
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub verificar_ninguna_igual()
        If resultado = 0 Then
            Label12.Text = ("ninguna igual")
            resultado = 1
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If clicku = 0 Then
            Label9.Text = apuesta + Int(Label9.Text)
            apuesta = 0
            Label2.Text = Int(azar.Next(1, 14))
            Label3.Text = Int(azar.Next(1, 14))
            Label4.Text = Int(azar.Next(1, 14))
            Label5.Text = Int(azar.Next(1, 14))
            Label6.Text = Int(azar.Next(1, 14))
            clicku = 1
            'MsgBox(Int(Label1.Text))
            verificar_quinteto()
            verificar_cuarteto()
            verificar_trio_par()
            verificar_trio()
            verificar_doble_par()
            verificar_par()
            verificar_ninguna_igual()
            Label1.Text = 0
        End If
    End Sub
End Class

﻿Public Class Form1
    Dim valordia1, valordia2, valormes1, valormes2, resultado, valoranio1, valoranio2, resultadoa, resultadob As Integer
    Dim Mes(12) As Integer
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End
    End Sub
    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        'Label1.Text = ListBox1.SelectedItem
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        calculo()
        'valor1 = Mes(ListBox1.SelectedItem)
        'MsgBox("dias de atraso = " & valor1)
        'MsgBox(Mes(ListBox2.SelectedItem) - Mes(ListBox1.SelectedItem))

        'valormes1 = ListBox1.SelectedItem
        'valormes2 = ListBox2.SelectedItem
        'For diferencia = valormes1 To valormes2
        ' resultado = resultado + Mes(diferencia)
        ' MsgBox(resultado)
        ' Next
        'resultado = 0
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        valordia1 = 0
        valordia2 = 0
        valormes1 = 0
        valormes2 = 0
        valoranio1 = 0
        valoranio2 = 0
        resultado = 0
        resultadoa = 0
        resultadob = 0
        Mes(1) = 31
        Mes(2) = 28
        Mes(3) = 31
        Mes(4) = 30
        Mes(5) = 31
        Mes(6) = 30
        Mes(7) = 31
        Mes(8) = 31
        Mes(9) = 30
        Mes(10) = 31
        Mes(11) = 30
        Mes(12) = 31

    End Sub
    Private Sub calculo()
        valordia1 = TextBox1.Text
        valordia2 = TextBox2.Text
        valormes1 = ListBox1.SelectedItem
        valormes2 = ListBox2.SelectedItem
        valoranio1 = ListBox3.SelectedItem
        valoranio2 = ListBox4.SelectedItem
        If valoranio1 = valoranio2 Then
            If valormes1 = valormes2 Then

                If valordia1 < valordia2 Then
                    MsgBox("dias de atraso=" & valordia2 - valordia1)
                ElseIf valordia1 > valordia2 Then
                    MsgBox("pago anticipado, no hay multa")
                ElseIf valordia1 = valordia2 Then
                    MsgBox("pago al dia, no hay multa")
                End If



            ElseIf valormes1 < valormes2 Then
                For diferencia = valormes1 To valormes2
                    resultado = resultado + Mes(diferencia)
                    'MsgBox(resultado)
                Next
                resultado = resultado - valordia1
                resultado = resultado - Mes(valormes2)
                resultado = resultado + valordia2
                MsgBox("dias de atraso=" & resultado)
                resultado = 0

            ElseIf valormes1 > valormes2 Then
                MsgBox("pago anticipado, no hay multa")
            End If



        ElseIf valoranio1 < valoranio2 Then
            For diferencia = 1 To valormes2
                resultadoa = resultadoa + Mes(diferencia)
            Next
            resultadoa = resultadoa - Mes(valormes2)
            resultadoa = resultadoa + valordia2
            For diferencia = valormes1 To 12
                resultadob = resultadob + Mes(diferencia)
            Next
            resultadob = resultadob - valordia1
            resultado = resultadoa + resultadob
            MsgBox("dias de atraso=" & resultado)
            resultadoa = 0
            resultadob = 0
            resultado = 0
        ElseIf valoranio1 > valoranio2 Then
            MsgBox("pago anticipado, no hay multa")
        End If

    End Sub
End Class

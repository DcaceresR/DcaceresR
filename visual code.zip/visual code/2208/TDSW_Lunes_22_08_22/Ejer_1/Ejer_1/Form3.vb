﻿Public Class Form3
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' VOLVER AL FORM1
        Me.Close()
        ' ME.HIDE()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'IMPRESION DE VAR1
        MsgBox("EN FORM2...VAR1=" & VAR1)
    End Sub
End Class
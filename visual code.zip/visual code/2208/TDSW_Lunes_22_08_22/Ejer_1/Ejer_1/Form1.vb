﻿Public Class Form1
    'Dim VAR1 As Integer
    Dim foto, ruta As String
    Private Sub ListBox4_click(sender As Object, e As EventArgs) Handles ListBox4.Click
        ' traspasar foto a picurebox

        Try
            foto = "FIG_" & ListBox4.SelectedItem & ".ico"
            PictureBox1.Image = Image.FromFile(ruta & foto)
        Catch ex As Exception
            MsgBox("errorrr")
        End Try



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' IF-THEN-ELSE
        VAR1 = InputBox("DATO=")
        If VAR1 = 1 Then
            MsgBox("..SI....")
        Else
            MsgBox("..NO...")
        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ' FOR
        For I = 1 To 2 Step 0.5
            MsgBox(I)
        Next
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        'WHILE
        VAR1 = 1
        Do While VAR1 < 3
            MsgBox(VAR1)
            VAR1 = VAR1 + 1
        Loop
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        ' REPEAT
        VAR1 = 1
        Do
            MsgBox(VAR1)
            VAR1 = VAR1 + 1
            ' VAR1 +=1
        Loop Until VAR1 > 3

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        'SELECT CASE
        VAR1 = InputBox("DATO=")
        Select Case VAR1
            Case 1
                MsgBox(" 1")
            Case 2
                MsgBox(" 2")

            Case > 6
                MsgBox(" MAYOR QUE 6")
            Case Else
                MsgBox(" NINGUNA DE LAS ANTERIORES....")

        End Select

    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        ' LLAMAR AL FORM2
        VAR1 = 999
        Form3.Show()
        'Form3.ShowDialog()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' LLENAR LISTBOX2
        ListBox2.Items.Add("PC")
        ListBox2.Items.Add("MOUSE")
        ListBox2.Items.Add("NOTEBOOK")
        ListBox2.Items.Add("PANTALLA")
        ListBox2.Items.Add("MEMORIA")
        'ruta = "C:\Users\Profe3\Desktop\Fotos_vb\"
        ruta = "..\..\Fotos_vb\"
    End Sub



    Private Sub ListBox2_Click(sender As Object, e As EventArgs) Handles ListBox2.Click
        ' TRASPASAR INFO DEL LISTBOX1 AL LISTBOX2
        ListBox3.Items.Add(ListBox2.SelectedItem)
        ListBox2.Items.RemoveAt(ListBox2.SelectedIndex)

    End Sub

    Private Sub ListBox3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox3.SelectedIndexChanged

    End Sub

    Private Sub ListBox3_CLICK(sender As Object, e As EventArgs) Handles ListBox3.Click
        ListBox2.Items.Add(ListBox3.SelectedItem)
        ListBox3.Items.RemoveAt(ListBox3.SelectedIndex)
    End Sub


End Class

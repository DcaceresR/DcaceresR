﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(620, 345)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(118, 54)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "to form1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(51, 364)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(123, 51)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "impresion de valores"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(68, 38)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(77, 42)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Button2"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(188, 39)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(77, 41)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "Button3"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(322, 44)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(95, 36)
        Me.Button5.TabIndex = 4
        Me.Button5.Tag = "5"
        Me.Button5.Text = "Button4"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Location = New System.Drawing.Point(88, 128)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(260, 107)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Label1"
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(70, 250)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(91, 40)
        Me.Button6.TabIndex = 6
        Me.Button6.Tag = "6"
        Me.Button6.Text = "Button5"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(198, 250)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(83, 35)
        Me.Button7.TabIndex = 7
        Me.Button7.Text = "Button6"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(322, 254)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(109, 36)
        Me.Button8.TabIndex = 8
        Me.Button8.Text = "Button7"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
End Class

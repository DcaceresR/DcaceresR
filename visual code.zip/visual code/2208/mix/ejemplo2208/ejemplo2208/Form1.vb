﻿Public Class Form1
    Public Property VAR1 As Integer
    Dim foto, ruta As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        VAR1 = InputBox("DATO=")
        If VAR1 = 1 Then
            MsgBox("..si...")
        Else
            MsgBox("..no....")
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        For I = 1 To 2 Step 0.5
            MsgBox(I)
        Next
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        VAR1 = 1
        Do While VAR1 < 3
            MsgBox(VAR1)
            VAR1 = VAR1 + 1
        Loop
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        VAR1 = 1
        Do
            MsgBox(VAR1)
            VAR1 = VAR1 + 1
        Loop Until VAR1 > 3
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        VAR1 = InputBox("DATO=")
        Select Case VAR1
            Case 1
                MsgBox("1")
            Case 2
                MsgBox("2")
            Case > 6
                MsgBox("mayor que 6")
            Case Else
                MsgBox("ninguna de las anteriores...")
        End Select

    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        'Form2.Show()
        Form2.ShowDialog()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListBox2.Items.Add("uno")
        ListBox2.Items.Add("dos")
        ListBox2.Items.Add("tres")
        ListBox2.Items.Add("cuatro")
        ruta = "C:\Users\Bear\Desktop\Fotos_VB\"
    End Sub

    Private Sub ListBox2_MouseClick(sender As Object, e As MouseEventArgs) Handles ListBox2.MouseClick
        ListBox3.Items.Add(ListBox2.SelectedItem)
        ListBox2.Items.RemoveAt(ListBox2.SelectedIndex)
    End Sub

    Private Sub ListBox3_Click(sender As Object, e As EventArgs) Handles ListBox3.Click
        ListBox2.Items.Add(ListBox3.SelectedItem)
        ListBox3.Items.RemoveAt(ListBox3.SelectedIndex)
    End Sub

    Private Sub ListBox4_Click(sender As Object, e As EventArgs) Handles ListBox4.Click
        Try
            foto = "FIG_" & ListBox4.SelectedItem & ".ico"
            PictureBox1.Image = Image.FromFile(ruta & foto)
        Catch ex As Exception
            MsgBox("error")
        End Try
    End Sub
End Class

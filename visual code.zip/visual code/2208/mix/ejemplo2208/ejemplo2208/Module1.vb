﻿Module Module1
    Public VAR1 As Integer
End Module

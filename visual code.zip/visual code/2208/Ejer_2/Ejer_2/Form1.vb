﻿Public Class Form1
    Dim aleatorio As New Random()
    Dim boton As Button()
    Dim indice, posy As Integer


    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        ' crear  botones
        posy = 200
        boton = New Button(6) {}
        indice = 1
        For fila = 1 To 3
            For col = 1 To 3
                boton(fila) = New Button()
                boton(fila).Size = New Size(100, 100)
                boton(fila).Location = New Point(100 * col, posy)
                boton(fila).Tag = indice
                indice = indice + 1
                Me.Controls.Add(boton(fila))
                AddHandler boton(fila).Click, AddressOf manejo_click
            Next
            posy = posy + 100
        Next
    End Sub


    Private Sub manejo_click(sender As Object, e As EventArgs)
        MsgBox(sender.tag)
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Label1.Text = "boton 2"
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Label1.Text = "boton 3"
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Label1.Text = "boton 4"
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs)
        '  MsgBox(Button5.Tag)
    End Sub

    Private Sub boton_click(sender As Object, e As EventArgs) Handles Button7.Click, Button6.Click, Button5.Click
        ' maneja los botones 5,6 y 7
        MsgBox(sender.tag)
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        ' uso de find.
        For var1 = 2 To 3
            Me.Controls.Find("button" & var1, Visible).FirstOrDefault().BackColor = Color.Red
        Next






    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        ' numero aleatorio antiguo
        MsgBox(Int(Rnd() * 5 + 5))
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        ' numero aleatorio version POO
        MsgBox(aleatorio.Next(5, 10))
    End Sub


End Class

﻿Public Class Form1
    Dim filas, columnas, num_lbl, posx, posy, barra, asta, limiteizq, limiteder, whiter As Integer
    Dim LBL As Label()
    'by Diego Cáceres Romero 702 12:39 03/10/2022
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        limiteizq = limiteizq + 10
        limiteder = limiteder + 10
        If barra >= 251 Then
            Timer1.Enabled = False
        Else
            LBL(barra).BackColor = Color.Red
            barra = barra + 10
            For i = 1 To 1
                LBL(whiter).BackColor = Color.White
                whiter = whiter + 1
                LBL(whiter).BackColor = Color.White
                whiter = whiter + 1
                LBL(whiter).BackColor = Color.White
                whiter = whiter + 1
                LBL(whiter).BackColor = Color.White
                whiter = whiter + 1
                LBL(whiter).BackColor = Color.White
                whiter = whiter + 1
                LBL(whiter).BackColor = Color.White
                whiter = whiter + 1
                LBL(whiter).BackColor = Color.White
                whiter = whiter + 1
                LBL(whiter).BackColor = Color.White
                whiter = whiter + 1
                LBL(whiter).BackColor = Color.White
                whiter = whiter + 1
                LBL(whiter).BackColor = Color.White
                whiter = whiter + 1
            Next
        End If

    End Sub

    Private Sub Jugar()
        Timer1.Enabled = True
        barra = 5
        asta = 4
        whiter = 1
        limiteizq = 41
        limiteder = 50
        For i = 1 To asta
            LBL(barra).BackColor = Color.Red
            barra = barra + 10
        Next
    End Sub

    Private Sub CrearCuadrados()
        filas = 25
        columnas = 10
        num_lbl = 0
        posx = 20
        posy = 80
        LBL = New Label(3000) {}
        For i = 1 To filas
            For j = 1 To columnas
                num_lbl = num_lbl + 1
                LBL(num_lbl) = New Label()
                LBL(num_lbl).Size = New Size(20, 20)
                LBL(num_lbl).Location = New Point(posx * j + 430, posy)
                LBL(num_lbl).BorderStyle = BorderStyle.FixedSingle
                LBL(num_lbl).Tag = num_lbl
                LBL(num_lbl).BackColor = Color.White
                Me.Controls.Add(LBL(num_lbl))
            Next
            posy = posy + 20
        Next
        Jugar()
    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = 27 Then
            End
        End If
        If e.KeyCode = 37 Then
            If barra <= limiteizq Then

            Else
                LBL(barra - 40).BackColor = Color.White
                LBL(barra - 30).BackColor = Color.White
                LBL(barra - 20).BackColor = Color.White
                LBL(barra - 10).BackColor = Color.White
                LBL(barra).BackColor = Color.White
                LBL(barra - 41).BackColor = Color.Red
                LBL(barra - 31).BackColor = Color.Red
                LBL(barra - 21).BackColor = Color.Red
                LBL(barra - 11).BackColor = Color.Red
                barra = barra - 1
            End If
        End If
        If e.KeyCode = 39 Then
            If barra >= limiteder Then

            Else
                LBL(barra - 40).BackColor = Color.White
                LBL(barra - 30).BackColor = Color.White
                LBL(barra - 20).BackColor = Color.White
                LBL(barra - 10).BackColor = Color.White
                LBL(barra).BackColor = Color.White
                LBL(barra - 39).BackColor = Color.Red
                LBL(barra - 29).BackColor = Color.Red
                LBL(barra - 19).BackColor = Color.Red
                LBL(barra - 9).BackColor = Color.Red
                barra = barra + 1
            End If

        End If
    End Sub

    Private Sub JuegoNuevoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JuegoNuevoToolStripMenuItem.Click
        CrearCuadrados()
    End Sub
End Class
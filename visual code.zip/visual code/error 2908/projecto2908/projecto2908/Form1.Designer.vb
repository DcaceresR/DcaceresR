﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.NivelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Novato24ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Intermedio44ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Experto56ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TDSWToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(706, 340)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(82, 69)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Fin"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NivelToolStripMenuItem, Me.TDSWToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'NivelToolStripMenuItem
        '
        Me.NivelToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Novato24ToolStripMenuItem, Me.Intermedio44ToolStripMenuItem, Me.Experto56ToolStripMenuItem})
        Me.NivelToolStripMenuItem.Name = "NivelToolStripMenuItem"
        Me.NivelToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.NivelToolStripMenuItem.Text = "Nivel"
        '
        'Novato24ToolStripMenuItem
        '
        Me.Novato24ToolStripMenuItem.Name = "Novato24ToolStripMenuItem"
        Me.Novato24ToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.Novato24ToolStripMenuItem.Text = "Novato(2,4)"
        '
        'Intermedio44ToolStripMenuItem
        '
        Me.Intermedio44ToolStripMenuItem.Name = "Intermedio44ToolStripMenuItem"
        Me.Intermedio44ToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.Intermedio44ToolStripMenuItem.Text = "Intermedio(4,4)"
        '
        'Experto56ToolStripMenuItem
        '
        Me.Experto56ToolStripMenuItem.Name = "Experto56ToolStripMenuItem"
        Me.Experto56ToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.Experto56ToolStripMenuItem.Text = "Experto(5,6)"
        '
        'TDSWToolStripMenuItem
        '
        Me.TDSWToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2})
        Me.TDSWToolStripMenuItem.Name = "TDSWToolStripMenuItem"
        Me.TDSWToolStripMenuItem.Size = New System.Drawing.Size(50, 20)
        Me.TDSWToolStripMenuItem.Text = "TDSW"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(92, 22)
        Me.ToolStripMenuItem2.Text = "702"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(635, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 15)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Numero de Click="
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Location = New System.Drawing.Point(745, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(15, 17)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "0"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 421)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents NivelToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Novato24ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Intermedio44ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Experto56ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TDSWToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class

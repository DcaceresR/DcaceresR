﻿Public Class Form1
    Dim NIVEL, FILAS, COLUMNAS, NUM_PICT As Integer
    Dim POSX, POSY, vector(30), n1, n2, paso As Integer
    Dim PICT As PictureBox()
    Dim aleatorio As New Random()
    Dim foto, ruta As String
    Private Sub desordenar_numeros()
        Select Case NIVEL
            Case 1
            Case 2
            Case 3
                For i = 1 To 30
                    If i <= 15 Then
                        vector(i) = i
                    Else
                        vector(i) = 15
                    End If
                Next

                For i = 1 To 100
                    n1 = aleatorio.Next(1, 31)
                    n2 = aleatorio.Next(1, 31)
                    paso = vector(n1)
                    vector(n1) = vector(n2)
                    vector(n2) = paso
                Next


                '              For i = 1 To 30
                '             foto = "FIG_" & vector(i) & ".ico"
                '            PICT(i).Image = Image.FromFile(ruta & foto)
                '           Next
                vector(1) = 1
                vector(2) = 1
        End Select
    End Sub
    Private Sub FOTO_CLICK(sender As Object, e As EventArgs)
        ' MsgBox(sender.tag)
        Conta_click = conta_click + 1
        numero_click = desordenar_numeros_click + 1
        foto = "FIG_" & vector(sender.tag) & ".ico"
        PICT(sender.tag).Image = Image.FromFile(ruta & foto)
        PICT(sender.tag).BackColor = Color.Transparent
        ''if numero_fot01 = numero_foto2 Then

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ruta = "..\..\fotos_vb\"
    End Sub

    Private Sub BORRAR_CUADRADOS()
        For i = 1 To 5
            For Each xpict In Controls
                If TypeOf xpict Is PictureBox Then
                    Me.Controls.Remove(xpict)
                End If
            Next
        Next
    End Sub
    Private Sub CREAR_CUADRADOS()
        BORRAR_CUADRADOS()
        Select Case NIVEL
            Case 1
                FILAS = 2
                COLUMNAS = 4
            Case 2
                FILAS = 4
                COLUMNAS = 4
            Case 3
                FILAS = 5
                COLUMNAS = 6
        End Select

        NUM_PICT = 0
        POSX = 120
        POSY = 80
        PICT = New PictureBox(30) {}

        For I = 1 To FILAS
            For J = 1 To COLUMNAS
                NUM_PICT = NUM_PICT + 1
                PICT(NUM_PICT) = New PictureBox()
                PICT(NUM_PICT).Size = New Size(140, 140)
                PICT(NUM_PICT).Location = New Point(POSX * J, POSY)
                PICT(NUM_PICT).BorderStyle = BorderStyle.FixedSingle
                PICT(NUM_PICT).SizeMode = PictureBoxSizeMode.StretchImage
                PICT(NUM_PICT).Tag = NUM_PICT
                PICT(NUM_PICT).BackColor = Color.Blue

                Me.Controls.Add(PICT(NUM_PICT))
                AddHandler PICT(NUM_PICT).Click, AddressOf FOTO_CLICK
            Next
            POSY = POSY + 120
        Next
    End Sub
    Private Sub Novato24ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Novato24ToolStripMenuItem.Click
        NIVEL = 1
        CREAR_CUADRADOS()
        desordenar_numeros()
    End Sub
    Private Sub Intermedio44ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Intermedio44ToolStripMenuItem.Click
        NIVEL = 2
        CREAR_CUADRADOS()
        desordenar_numeros()
    End Sub
    Private Sub Experto56ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Experto56ToolStripMenuItem.Click
        NIVEL = 3
        CREAR_CUADRADOS()
        desordenar_numeros()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub
End Class

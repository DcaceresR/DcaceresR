﻿Public Class Form1
    Dim posx, posy As Integer
    Dim l1, l2, l3, l4 As Integer

    Private Sub Verificar_pared()
        If Pict1.Left >= l1 And Pict1.Left <= l2 Then
            If Pict1.Top >= l3 And Pict1.Top < l4 Then
                'If Pict1.Left > l3 And Pict1.Left < l4 Then
                'If Pict1.Top > l1 And Pict1.Top < l3 Then
                posx = -20
                posy = -10
                If Pict2.BackColor = Color.Blue Then
                    Pict2.BackColor = Color.Red
                Else
                    Pict2.BackColor = Color.Blue
                End If
                'End If
                'End If
            End If
        End If
    End Sub
    Private Sub verifica_limites()
        If Pict1.Left + 50 > Me.Width Then
            Timer1.Enabled = False
            MsgBox("fin de certamen")
            'posx = -50
        End If
        If Pict1.Left - 15 < 0 Then
            'Timer1.Enabled = False
            'posy = 25
            posx = 20
        End If
        If Pict1.Top - 15 < 0 Then
            'Timer1.Enabled = False
            'posx = -25
            posy = 20
        End If
        If Pict1.Top + 55 > Me.Height Then
            'Timer1.Enabled = False
            posy = -20
            'posx = 55
        End If
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Pict1.Left = Pict1.Left + posx
        Pict1.Top = Pict1.Top + posy
        verifica_limites()
        Verificar_pared()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        l1 = Pict2.Left
        l2 = l1 + Pict2.Width
        l3 = Pict2.Top
        l4 = l3 + Pict2.Width
        'MsgBox(l1 & " " & l2 & " " & l3 & " " & l4)

        Timer1.Enabled = True
        posx = 20
        posy = 0 '50
    End Sub
    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        Select Case e.KeyCode
            Case 38 'arriba
                Pict2.Top = Pict2.Top - 25
            Case 40 'abajo
                Pict2.Top = Pict2.Top + 25
            Case 27 'esc
                End
        End Select
    End Sub
End Class

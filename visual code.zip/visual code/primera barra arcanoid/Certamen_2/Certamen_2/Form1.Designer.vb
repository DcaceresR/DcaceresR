﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Pict1 = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Pict2 = New System.Windows.Forms.PictureBox()
        CType(Me.Pict1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pict2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pict1
        '
        Me.Pict1.Image = CType(resources.GetObject("Pict1.Image"), System.Drawing.Image)
        Me.Pict1.Location = New System.Drawing.Point(436, 233)
        Me.Pict1.Name = "Pict1"
        Me.Pict1.Size = New System.Drawing.Size(33, 33)
        Me.Pict1.TabIndex = 0
        Me.Pict1.TabStop = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 200
        '
        'Pict2
        '
        Me.Pict2.BackColor = System.Drawing.Color.Blue
        Me.Pict2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pict2.Location = New System.Drawing.Point(775, 197)
        Me.Pict2.Name = "Pict2"
        Me.Pict2.Size = New System.Drawing.Size(68, 158)
        Me.Pict2.TabIndex = 1
        Me.Pict2.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(903, 472)
        Me.Controls.Add(Me.Pict2)
        Me.Controls.Add(Me.Pict1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.Pict1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pict2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Pict1 As PictureBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Pict2 As PictureBox
End Class

﻿Public Class Form1
    Dim posx, posy, posx2, posy2 As Integer

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
        posx = 50
        posy = 50

        posx2 = -40
        posy2 = -30
    End Sub

    Private Sub Form1_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        Label3.Text = Me.Width
        Label4.Text = Me.Height
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Pict1.Left = Pict1.Left + 25
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Pict1.Left = Pict1.Left - 25
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Pict1.Top = Pict1.Top - 25
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Pict1.Top = Pict1.Top + 25
    End Sub

    Private Sub verifica_limites()
        If Pict1.Left + 50 > Me.Width Then
            'Timer1.Enabled = False
            posx = -50
        End If
        If Pict1.Left - 15 < 0 Then
            'Timer1.Enabled = False
            'posy = 25
            posx = 25
        End If
        If Pict1.Top - 15 < 0 Then
            'Timer1.Enabled = False
            'posx = -25
            posy = 25
        End If
        If Pict1.Top + 55 > Me.Height Then
            'Timer1.Enabled = False
            posy = -55
            'posx = 55
        End If

        If Pict2.Left + 50 > Me.Width Then
            'Timer1.Enabled = False
            posx2 = -50
        End If
        If Pict2.Left - 15 < 0 Then
            'Timer1.Enabled = False
            'posy = 25
            posx2 = 25
        End If
        If Pict2.Top - 15 < 0 Then
            'Timer1.Enabled = False
            'posx = -25
            posy2 = 25
        End If
        If Pict2.Top + 55 > Me.Height Then
            'Timer1.Enabled = False
            posy2 = -55
            'posx = 55
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Pict1.Left = Pict1.Left + posx
        Pict1.Top = Pict1.Top + posy

        Pict2.Left = Pict2.Left + posx2
        Pict2.Top = Pict2.Top + posy2
        verifica_limites()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Timer1.Enabled = True
    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = 37 Then
            MsgBox("tecla IZQ, codigo=37")
        End If
    End Sub
End Class

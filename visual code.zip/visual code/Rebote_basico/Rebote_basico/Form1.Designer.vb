﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Pict1 = New System.Windows.Forms.PictureBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Pict2 = New System.Windows.Forms.PictureBox()
        CType(Me.Pict1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pict2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(687, 262)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(101, 62)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Fin"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(618, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Form_width="
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(618, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Form_height="
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(709, 11)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(13, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(709, 47)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(13, 15)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "0"
        '
        'Pict1
        '
        Me.Pict1.Image = Global.Rebote_basico.My.Resources.Resources.FIG_4
        Me.Pict1.Location = New System.Drawing.Point(292, 128)
        Me.Pict1.Name = "Pict1"
        Me.Pict1.Size = New System.Drawing.Size(33, 33)
        Me.Pict1.TabIndex = 3
        Me.Pict1.TabStop = False
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(652, 82)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(82, 40)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "arriba"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(702, 128)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(82, 40)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "derecha"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(652, 174)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(82, 40)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "abajo"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(614, 128)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(82, 40)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "izquierda"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(665, 225)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(56, 24)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "Partir"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Pict2
        '
        Me.Pict2.Image = Global.Rebote_basico.My.Resources.Resources.FIG_3
        Me.Pict2.Location = New System.Drawing.Point(358, 128)
        Me.Pict2.Name = "Pict2"
        Me.Pict2.Size = New System.Drawing.Size(33, 33)
        Me.Pict2.TabIndex = 3
        Me.Pict2.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(801, 332)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Pict2)
        Me.Controls.Add(Me.Pict1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.Pict1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pict2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Pict1 As PictureBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Button6 As Button
    Friend WithEvents Pict2 As PictureBox
End Class

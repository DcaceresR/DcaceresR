﻿Public Class Form1
    'izq=37
    'up=38
    'right=39
    'down=40
    'barra=32
    'enter=13
    'retroceso=8
    'esc=27
    'suprimir=46
    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        MsgBox("codigo de tecla presionada = " & e.KeyCode)
        Select Case e.KeyCode
            Case 37
            Case 38
            Case 39
            Case 40
            Case 27
                End
        End Select
        If e.KeyCode = 37 Then
            'MsgBox("tecla izquierda, codigo = 37")
            PictureBox1.Left = PictureBox1.Left - 50
        End If
        If e.KeyCode = 38 Then
            'MsgBox("tecla arriba, codigo = 37")
            PictureBox1.Top = PictureBox1.Top - 50
        End If
        If e.KeyCode = 39 Then
            'MsgBox("tecla derecha, codigo = 37")
            PictureBox1.Left = PictureBox1.Left + 50
        End If
        If e.KeyCode = 40 Then
            'MsgBox("tecla abajo, codigo = 37")
            PictureBox1.Top = PictureBox1.Top + 50
        End If
    End Sub
End Class

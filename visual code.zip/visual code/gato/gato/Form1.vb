﻿Public Class Form1
    Dim ruta, foto As String
    Dim vector(9), j As Integer
    Dim jugador As Integer
    Dim var1, var2, var3, var4, var5, var6, var7, var8, var9 As Integer
    Dim cual_click As Integer

    Private Sub bloqueo_ganar()
        For Each xcontrol In Me.Controls
            If TypeOf xcontrol Is PictureBox Then
                xcontrol.enabled = False
            End If
        Next
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        jugador = 1

        'var1 = 0
        'var2 = 0
        'var3 = 0
        'var4 = 0
        'var5 = 0
        'var6 = 0
        'var7 = 0
        'var8 = 0
        'var9 = 0

        For i = 1 To 9
            vector(i) = 0
        Next

        'PictureBox1.Enabled = True
        'PictureBox2.Enabled = True
        'PictureBox3.Enabled = True
        'PictureBox4.Enabled = True
        'PictureBox5.Enabled = True
        'PictureBox6.Enabled = True
        'PictureBox7.Enabled = True
        'PictureBox8.Enabled = True
        'PictureBox9.Enabled = True

        For Each xcontrol In Me.Controls
            If TypeOf xcontrol Is PictureBox Then
                xcontrol.enabled = True
                xcontrol.image = Nothing
            End If
        Next

        'PictureBox1.Image = Nothing
        'PictureBox2.Image = Nothing
        'PictureBox3.Image = Nothing
        'PictureBox4.Image = Nothing
        'PictureBox5.Image = Nothing
        'PictureBox6.Image = Nothing
        'PictureBox7.Image = Nothing
        'PictureBox8.Image = Nothing
        'PictureBox9.Image = Nothing
    End Sub
    Private Sub verificar_ganar()
        j = 1
        For fila = 1 To 3
            If vector(j) <> 0 And vector(j + 1) <> 0 And vector(j + 2) Then
                If vector(j) = vector(j + 1) And vector(j + 1) = vector(j + 2) Then
                    MsgBox("ganó el jugador =" & jugador)
                    bloqueo_ganar()
                End If
            End If
            j = j + 3
        Next

        j = 1
        For columna = 1 To 3
            If vector(j) <> 0 And vector(j + 3) <> 0 And vector(j + 6) Then
                If vector(j) = vector(j + 3) And vector(j + 3) = vector(j + 6) Then
                    MsgBox("ganó el jugador =" & jugador)
                    bloqueo_ganar()
                End If
            End If
            j = j + 1
        Next

        'If var1 <> 0 And var2 <> 0 And var3 <> 0 Then
        ' If var1 = var2 And var2 = var3 Then
        '      MsgBox("Ganó el jugador =" & jugador)
        '   End If
        'End If
        'If var4 <> 0 And var5 <> 0 And var6 <> 0 Then
        ' If var4 = var5 And var5 = var6 Then
        '      MsgBox("Ganó el jugador =" & jugador)
        '   End If
        'End If
        'If var7 <> 0 And var8 <> 0 And var9 <> 0 Then
        ' If var7 = var8 And var8 = var9 Then
        '      MsgBox("Ganó el jugador =" & jugador)
        '   End If
        'End If
        'If var1 <> 0 And var4 <> 0 And var7 <> 0 Then
        '  If var1 = var4 And var4 = var7 Then
        '      MsgBox("Ganó el jugador =" & jugador)
        '   End If
        'End If
        'If var2 <> 0 And var5 <> 0 And var8 <> 0 Then
        ' If var2 = var5 And var5 = var8 Then
        '      MsgBox("Ganó el jugador =" & jugador)
        '   End If
        'End If
        'If var3 <> 0 And var6 <> 0 And var9 <> 0 Then
        '     If var3 = var6 And var6 = var9 Then
        '          MsgBox("Ganó el jugador =" & jugador)
        '    End If
        'End If
        'If var1 <> 0 And var5 <> 0 And var9 <> 0 Then
        ' If var1 = var5 And var5 = var9 Then
        '      MsgBox("Ganó el jugador =" & jugador)
        '   End If
        'End If

        If vector(1) <> 0 And vector(5) <> 0 And vector(9) <> 0 Then
            If vector(1) = vector(5) And vector(5) = vector(9) Then
                MsgBox("Ganó el jugador =" & jugador)
                bloqueo_ganar()
            End If
        End If

        'If var3 <> 0 And var5 <> 0 And var7 <> 0 Then
        ' If var3 = var5 And var5 = var7 Then
        '      MsgBox("Ganó el jugador =" & jugador)
        '   End If
        'End If

        If vector(3) <> 0 And vector(5) <> 0 And vector(7) <> 0 Then
            If vector(3) = vector(5) And vector(5) = vector(7) Then
                MsgBox("Ganó el jugador =" & jugador)
                bloqueo_ganar()
            End If
        End If

    End Sub
    Private Sub traspaso()
        For i = 1 To 9
            If i = cual_click Then
                vector(i) = jugador
            End If
        Next

        '       Select Case cual_click
        '      Case 1
        '     var1 = jugador
        '    Case 2
        '   var2 = jugador
        '  Case 3
        ' var3 = jugador
        'Case 4
        'var4 = jugador
        'Case 5
        'var5 = jugador
        'Case 6
        'var6 = jugador
        'Case 7
        'var7 = jugador
        'Case 8
        'var8 = jugador
        'Case 9
        'var9 = jugador
        'End Select
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ruta = "..\..\Fotos_VB\"
        jugador = 1
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub
    Private Sub gato_Click(sender As Object, e As EventArgs) Handles PictureBox9.Click, PictureBox8.Click, PictureBox7.Click, PictureBox6.Click, PictureBox5.Click, PictureBox4.Click, PictureBox3.Click, PictureBox2.Click, PictureBox1.Click
        cual_click = sender.tag
        If jugador = 1 Then
            If sender.enabled = True Then
                sender.image = Image.FromFile(ruta & "FIG_4.ico")
                sender.enabled = False
                traspaso()
                verificar_ganar()
                jugador = 2
            End If
        Else
            If sender.enabled = True Then
                sender.image = Image.FromFile(ruta & "DISK04.ico")
                sender.enabled = False
                traspaso()
                verificar_ganar()
                jugador = 1
            End If
        End If
    End Sub
End Class